</main><!-- End #main -->
<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="container footer-bottom clearfix">
        <div class="copyright">
            &copy; Copyright <strong><span>WBSUPICibiru</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/ -->
            <!-- WBSUPICibiru<a href="https://dekasoft.my.id" target="_blank" class="font-weight-bolder">SWBSUPICibiru</a> @2022 -->
        </div>
    </div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>
<div id="preloader"></div>


<div class="whats-float">
    <a href="https://api.whatsapp.com/send?phone=<?php echo $profile['telp_profile']; ?>" target="_blank">
        <i class="fa fa-whatsapp"></i><span>WhatsApp<br><small>+<?php echo $profile['telp_profile']; ?></small></span>
    </a>
</div>


<!-- Vendor JS Files -->
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/php-email-form/validate.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/venobox/venobox.min.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="<?php echo base_url('vendor/'); ?>assets/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="<?php echo base_url('vendor/'); ?>assets/js/main.js"></script>


</body>

</html>